# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '8046928a6c96a3b9f35c90ee85585fb69d386e965e82a6ab5011726d5905d8d753b08c5dc82c06f09e54e2c09cffd23b427f3c2f3cc7ee7e1928966247f60c2e'
